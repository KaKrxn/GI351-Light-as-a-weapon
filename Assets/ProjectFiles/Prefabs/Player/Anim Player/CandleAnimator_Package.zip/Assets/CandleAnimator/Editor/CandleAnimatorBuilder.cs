using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;
using System.Linq;
using System.Collections.Generic;

public static class CandleAnimatorBuilder
{
    const string ControllerName = "Candle Animator.controller";
    const string MenuPath = "Tools/Candle/Build Animator";
    const string DefaultFolder = "Assets/CandleAnimator";

    // Animator parameter names
    static readonly string[] BoolParams = new[] {
        "IsJumping", "IsDoubleJumping", "IsWallClinging", "IsWallSliding",
        "IsDashing", "IsDead", "FacingRight"
    };
    static readonly string[] FloatParams = new[] { "SpeedX", "SpeedY" };

    // Clip name suggestions (we'll auto-bind if found in project)
    static readonly string[] ClipsGround = new[] { "Idle", "Walk", "Run" };
    static readonly string[] ClipsAir    = new[] { "Jump_Up", "Apex", "Fall" };
    static readonly string[] ClipsWall   = new[] { "WallCling_Loop", "WallSlide_Loop" };
    static readonly string   ClipDouble  = "DoubleJump";
    static readonly string   ClipDash    = "Dash_Fullbody";
    static readonly string   ClipDie     = "Die";
    static readonly string   ClipDashOverlay = "Dash_Overlay";

    [MenuItem(MenuPath)]
    public static void Build()
    {
        // Ensure folder
        if (!AssetDatabase.IsValidFolder(DefaultFolder))
        {
            AssetDatabase.CreateFolder("Assets", "CandleAnimator");
        }

        string ctrlPath = $"{DefaultFolder}/{ControllerName}";

        // Create or reuse controller
        AnimatorController controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(ctrlPath);
        if (controller == null)
        {
            controller = AnimatorController.CreateAnimatorControllerAtPath(ctrlPath);
        }

        // Clear layers to a clean state (keep at least one base layer)
        while (controller.layers.Length > 0)
            controller.RemoveLayer(0);

        // Add base layer
        var baseLayer = new AnimatorControllerLayer
        {
            name = "Base Layer",
            defaultWeight = 1f,
            stateMachine = new AnimatorStateMachine { name = "Base StateMachine" }
        };
        controller.AddLayer(baseLayer);

        // Add UpperBody overlay layer (no mask by default; user can assign later)
        var upperLayer = new AnimatorControllerLayer
        {
            name = "UpperBody",
            defaultWeight = 1f,
            blendingMode = AnimatorLayerBlendingMode.Additive,
            stateMachine = new AnimatorStateMachine { name = "UpperBody StateMachine" }
        };
        controller.AddLayer(upperLayer);

        // Add parameters (avoid duplicates)
        var existParams = new HashSet<string>(controller.parameters.Select(p => p.name));
        foreach (var b in BoolParams) if (!existParams.Contains(b)) controller.AddParameter(b, AnimatorControllerParameterType.Bool);
        foreach (var f in FloatParams) if (!existParams.Contains(f)) controller.AddParameter(f, AnimatorControllerParameterType.Float);

        // Helper: find clip by name anywhere in project
        AnimationClip FindClip(string clipName)
        {
            var guids = AssetDatabase.FindAssets($"t:AnimationClip {clipName}");
            foreach (var g in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(g);
                var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(path);
                if (clip != null && clip.name == clipName)
                    return clip;
            }
            return null;
        }

        // Create motions if they exist
        AnimationClip[] groundClips = ClipsGround.Select(FindClip).ToArray();
        AnimationClip[] airClips    = ClipsAir.Select(FindClip).ToArray();
        var clipCling  = FindClip(ClipsWall[0]);
        var clipSlide  = FindClip(ClipsWall[1]);
        var clipDouble = FindClip(ClipDouble);
        var clipDash   = FindClip(ClipDash);
        var clipDie    = FindClip(ClipDie);
        var clipDashOv = FindClip(ClipDashOverlay);

        // ===== Base Layer State Machine =====
        var sm = controller.layers[0].stateMachine;

        // 1) Locomotion Blend Tree (SpeedX)
        var locoBT = new BlendTree { name = "Locomotion_BT", blendType = BlendTreeType.Simple1D, useAutomaticThresholds = false };
        locoBT.blendParameter = "SpeedX";
        AssetDatabase.AddObjectToAsset(locoBT, controller);
        var locoState = sm.AddState("Locomotion_BT");
        locoState.motion = locoBT;

        // add 3 child motions for Idle/Walk/Run (null if not found; user can assign later)
        AddChild(locoBT, groundClips.ElementAtOrDefault(0), 0f);   // Idle
        AddChild(locoBT, groundClips.ElementAtOrDefault(1), 1f);   // Walk
        AddChild(locoBT, groundClips.ElementAtOrDefault(2), 4f);   // Run

        // 2) Air Blend Tree (SpeedY)
        var airBT = new BlendTree { name = "Air_BT", blendType = BlendTreeType.Simple1D, useAutomaticThresholds = false };
        airBT.blendParameter = "SpeedY";
        AssetDatabase.AddObjectToAsset(airBT, controller);
        var airState = sm.AddState("Air_BT");
        airState.motion = airBT;

        // child motions: Jump_Up (+6), Apex (0), Fall (-6)
        AddChild(airBT, airClips.ElementAtOrDefault(0), +6f);
        AddChild(airBT, airClips.ElementAtOrDefault(1), 0f);
        AddChild(airBT, airClips.ElementAtOrDefault(2), -6f);

        // 3) DoubleJump
        var doubleState = sm.AddState("DoubleJump");
        doubleState.motion = clipDouble; // may be null

        // 4) WallCling & WallSlide
        var clingState = sm.AddState("WallCling_Loop");
        clingState.motion = clipCling; // may be null
        var slideState = sm.AddState("WallSlide_Loop");
        slideState.motion = clipSlide; // may be null

        // 5) Dash (Base layer fullbody)
        var dashState = sm.AddState("Dash_Fullbody");
        dashState.motion = clipDash; // may be null

        // 6) Die
        var dieState = sm.AddState("Die");
        dieState.motion = clipDie; // may be null

        // Set entry
        sm.defaultState = locoState;

        // ===== Transitions =====

        // Locomotion -> Air
        var toAir = locoState.AddTransition(airState);
        toAir.hasExitTime = false; toAir.duration = 0.05f;
        toAir.AddCondition(AnimatorConditionMode.If, 0f, "IsJumping");

        // Air -> Locomotion
        var toGround = airState.AddTransition(locoState);
        toGround.hasExitTime = false; toGround.duration = 0.05f;
        toGround.AddCondition(AnimatorConditionMode.IfNot, 0f, "IsJumping");

        // Air -> DoubleJump
        var toDouble = airState.AddTransition(doubleState);
        toDouble.hasExitTime = false; toDouble.duration = 0.01f;
        toDouble.AddCondition(AnimatorConditionMode.If, 0f, "IsDoubleJumping");

        // DoubleJump -> Air
        var backAir = doubleState.AddTransition(airState);
        backAir.hasExitTime = true; backAir.exitTime = 0.9f; backAir.duration = 0.05f;

        // Any -> WallCling
        var anyToCling = sm.AddAnyStateTransition(clingState);
        anyToCling.hasExitTime = false; anyToCling.duration = 0.03f;
        anyToCling.AddCondition(AnimatorConditionMode.If, 0f, "IsWallClinging");

        // Any -> WallSlide
        var anyToSlide = sm.AddAnyStateTransition(slideState);
        anyToSlide.hasExitTime = false; anyToSlide.duration = 0.03f;
        anyToSlide.AddCondition(AnimatorConditionMode.If, 0f, "IsWallSliding");

        // Cling -> Slide
        var clingToSlide = clingState.AddTransition(slideState);
        clingToSlide.hasExitTime = false; clingToSlide.duration = 0.03f;
        clingToSlide.AddCondition(AnimatorConditionMode.IfNot, 0f, "IsWallClinging");
        clingToSlide.AddCondition(AnimatorConditionMode.If, 0f, "IsWallSliding");

        // Cling -> Air
        var clingToAir = clingState.AddTransition(airState);
        clingToAir.hasExitTime = false; clingToAir.duration = 0.03f;
        clingToAir.AddCondition(AnimatorConditionMode.IfNot, 0f, "IsWallClinging");
        clingToAir.AddCondition(AnimatorConditionMode.IfNot, 0f, "IsWallSliding");

        // Slide -> Air
        var slideToAir = slideState.AddTransition(airState);
        slideToAir.hasExitTime = false; slideToAir.duration = 0.03f;
        slideToAir.AddCondition(AnimatorConditionMode.IfNot, 0f, "IsWallSliding");

        // Any -> Dash
        var anyToDash = sm.AddAnyStateTransition(dashState);
        anyToDash.hasExitTime = false; anyToDash.duration = 0.02f;
        anyToDash.AddCondition(AnimatorConditionMode.If, 0f, "IsDashing");

        // Dash -> Locomotion (fallback)
        var dashBack = dashState.AddTransition(locoState);
        dashBack.hasExitTime = false; dashBack.duration = 0.02f;
        dashBack.AddCondition(AnimatorConditionMode.IfNot, 0f, "IsDashing");

        // Any -> Die
        var anyToDie = sm.AddAnyStateTransition(dieState);
        anyToDie.hasExitTime = false; anyToDie.duration = 0f;
        anyToDie.AddCondition(AnimatorConditionMode.If, 0f, "IsDead");

        // ===== UpperBody Layer (Additive) =====
        var smUpper = controller.layers[1].stateMachine;
        var noneState = smUpper.AddState("Overlay_None");
        var dashOvState = smUpper.AddState("Overlay_Dash");
        dashOvState.motion = clipDashOv; // may be null
        smUpper.defaultState = noneState;

        var upToDash = smUpper.AddAnyStateTransition(dashOvState);
        upToDash.hasExitTime = false; upToDash.duration = 0.02f;
        upToDash.AddCondition(AnimatorConditionMode.If, 0f, "IsDashing");

        var dashToNone = dashOvState.AddTransition(noneState);
        dashToNone.hasExitTime = false; dashToNone.duration = 0.02f;
        dashToNone.AddCondition(AnimatorConditionMode.IfNot, 0f, "IsDashing");

        // Save
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("Candle Animator", $"Created/Updated:\n{ctrlPath}\n\n"
            + "• Drag this controller to your Player's Animator.\n"
            + "• Assign your animation clips to states (if not auto-bound).", "OK");
    }

    static void AddChild(BlendTree bt, Motion motion, float threshold)
    {
        var childs = bt.children.ToList();
        var cm = new ChildMotion
        {
            motion = motion, // may be null; user can assign later
            threshold = threshold,
            timeScale = 1f,
            directBlendParameter = string.Empty
        };
        childs.Add(cm);
        bt.children = childs.ToArray();
    }
}
