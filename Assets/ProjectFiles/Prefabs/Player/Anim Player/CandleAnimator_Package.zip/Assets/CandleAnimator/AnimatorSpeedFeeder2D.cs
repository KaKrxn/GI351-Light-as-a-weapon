using UnityEngine;

[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(Rigidbody2D))]
public class AnimatorSpeedFeeder2D : MonoBehaviour
{
    public string speedXParam = "SpeedX";
    public string speedYParam = "SpeedY";

    Animator anim;
    Rigidbody2D rb;

    void Awake()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        if (!anim || !rb) return;
        float sx = Mathf.Abs(rb.linearVelocity.x);
        float sy = rb.linearVelocity.y;
        anim.SetFloat(speedXParam, sx);
        anim.SetFloat(speedYParam, sy);
    }
}
